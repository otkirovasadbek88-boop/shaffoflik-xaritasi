package uz.shaffoflik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShaffoflikApplication {
    public static void main(String[] args) {
        SpringApplication.run(ShaffoflikApplication.class, args);
    }
}
