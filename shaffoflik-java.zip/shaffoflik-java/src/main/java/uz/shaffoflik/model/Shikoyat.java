package uz.shaffoflik.model;

public class Shikoyat {
    private String viloyat;
    private String tashkilotNomi;
    private String xodimIsmi;
    private String soha;
    private String matn;
    private String aloqa; // Ixtiyoriy - anonim bo'lishi mumkin
    private String holat;

    public Shikoyat() {}

    // Getters va Setters
    public String getViloyat() { return viloyat; }
    public void setViloyat(String viloyat) { this.viloyat = viloyat; }

    public String getTashkilotNomi() { return tashkilotNomi; }
    public void setTashkilotNomi(String tashkilotNomi) { this.tashkilotNomi = tashkilotNomi; }

    public String getXodimIsmi() { return xodimIsmi; }
    public void setXodimIsmi(String xodimIsmi) { this.xodimIsmi = xodimIsmi; }

    public String getSoha() { return soha; }
    public void setSoha(String soha) { this.soha = soha; }

    public String getMatn() { return matn; }
    public void setMatn(String matn) { this.matn = matn; }

    public String getAloqa() { return aloqa; }
    public void setAloqa(String aloqa) { this.aloqa = aloqa; }

    public String getHolat() { return holat; }
    public void setHolat(String holat) { this.holat = holat; }

    // Anonim tekshirish
    public boolean isAnonim() {
        return aloqa == null || aloqa.trim().isEmpty();
    }
}
