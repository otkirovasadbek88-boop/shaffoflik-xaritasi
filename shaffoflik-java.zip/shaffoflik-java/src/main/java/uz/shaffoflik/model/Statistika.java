package uz.shaffoflik.model;

public class Statistika {
    private int jami;
    private int halQilindi;
    private int yangi;
    private int tekshirilmoqda;

    public Statistika(int jami, int halQilindi, int yangi, int tekshirilmoqda) {
        this.jami = jami;
        this.halQilindi = halQilindi;
        this.yangi = yangi;
        this.tekshirilmoqda = tekshirilmoqda;
    }

    // Getters
    public int getJami() { return jami; }
    public int getHalQilindi() { return halQilindi; }
    public int getYangi() { return yangi; }
    public int getTekshirilmoqda() { return tekshirilmoqda; }

    // Foiz hisoblash
    public double getHalQilindiForiz() {
        if (jami == 0) return 0;
        return Math.round((double) halQilindi / jami * 100 * 10.0) / 10.0;
    }
}
