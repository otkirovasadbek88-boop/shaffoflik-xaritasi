package uz.shaffoflik.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import uz.shaffoflik.model.Statistika;
import uz.shaffoflik.model.Shikoyat;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ShaffoflikController {

    // Xotira ichidagi ma'lumotlar (demo uchun)
    private List<Shikoyat> shikoyatlar = new ArrayList<>();

    /**
     * API holati tekshirish
     */
    @GetMapping("/")
    public ResponseEntity<Map<String, String>> home() {
        Map<String, String> javob = new HashMap<>();
        javob.put("xabar", "Shaffoflik Xaritasi Java API ishlayapti!");
        javob.put("versiya", "1.0.0");
        javob.put("til", "Java Spring Boot");
        return ResponseEntity.ok(javob);
    }

    /**
     * Statistika hisoblash
     * Bu Java ning asosiy vazifasi - tez hisoblash
     */
    @GetMapping("/statistika")
    public ResponseEntity<Map<String, Object>> statistika() {
        int jami = shikoyatlar.size() + 318; // Demo ma'lumotlar bilan
        int halQilindi = 187;
        int yangi = (int)(shikoyatlar.stream()
            .filter(s -> "yangi".equals(s.getHolat()))
            .count());
        int tekshirilmoqda = 47;

        Statistika stat = new Statistika(jami, halQilindi, yangi, tekshirilmoqda);

        Map<String, Object> javob = new HashMap<>();
        javob.put("jami", stat.getJami());
        javob.put("halQilindi", stat.getHalQilindi());
        javob.put("yangi", stat.getYangi());
        javob.put("tekshirilmoqda", stat.getTekshirilmoqda());
        javob.put("halQilindiForiz", stat.getHalQilindiForiz() + "%");

        return ResponseEntity.ok(javob);
    }

    /**
     * Viloyatlar bo'yicha statistika
     */
    @GetMapping("/statistika/viloyatlar")
    public ResponseEntity<Map<String, Integer>> viloyatlarStatistika() {
        Map<String, Integer> viloyatlar = new LinkedHashMap<>();
        viloyatlar.put("Toshkent shahri", 47);
        viloyatlar.put("Farg'ona viloyati", 38);
        viloyatlar.put("Buxoro viloyati", 34);
        viloyatlar.put("Andijon viloyati", 29);
        viloyatlar.put("Samarqand viloyati", 19);
        viloyatlar.put("Qashqadaryo viloyati", 22);
        viloyatlar.put("Namangan viloyati", 18);
        viloyatlar.put("Xorazm viloyati", 21);
        return ResponseEntity.ok(viloyatlar);
    }

    /**
     * Sohalar bo'yicha statistika
     */
    @GetMapping("/statistika/sohalar")
    public ResponseEntity<Map<String, Integer>> sohalarStatistika() {
        Map<String, Integer> sohalar = new LinkedHashMap<>();
        sohalar.put("Ta'lim", 89);
        sohalar.put("Sog'liqni saqlash", 67);
        sohalar.put("Qurilish", 54);
        sohalar.put("Kommunal", 43);
        sohalar.put("Moliya/Byudjet", 38);
        sohalar.put("Yer-mulk", 27);
        return ResponseEntity.ok(sohalar);
    }

    /**
     * Shikoyat qabul qilish
     */
    @PostMapping("/shikoyat")
    public ResponseEntity<Map<String, String>> shikoyatQabul(
            @RequestBody Shikoyat shikoyat) {

        // Majburiy maydonlarni tekshirish
        if (shikoyat.getViloyat() == null ||
            shikoyat.getTashkilotNomi() == null ||
            shikoyat.getMatn() == null) {
            Map<String, String> xato = new HashMap<>();
            xato.put("xato", "Majburiy maydonlar to'ldirilmagan!");
            return ResponseEntity.badRequest().body(xato);
        }

        // Anonim yoki yo'qligini tekshirish
        shikoyat.setHolat("yangi");
        shikoyatlar.add(shikoyat);

        Map<String, String> javob = new HashMap<>();
        javob.put("xabar", "Shikoyat muvaffaqiyatli qabul qilindi!");
        javob.put("anonim", shikoyat.isAnonim() ? "Ha" : "Yo'q");
        javob.put("holat", "yangi");

        return ResponseEntity.ok(javob);
    }
}
